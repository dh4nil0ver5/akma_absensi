<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class Absensi extends Model
{
    //
    protected $fillable = [
        'nip', 'username', 'shift', 'masuk', 'pulang', 'keterangan'];
        
    
    public static function excel_absensi(){
        $data = DB::table('history_exports')->get(); 
        $a = $data[0]->tanggal_range;
        $tgl1 = explode(" / ", $a)[0];
        $tgl2 = explode(" / ", $a)[1];
        
        $wherebetween = " WHERE b.admin='bukan admin' AND a.timestamp_masuk BETWEEN '".$tgl1."' AND '".$tgl2."'";
        $sql = "SELECT 
                    b.nip as nip,
                    b.name as username,
                    a.timestamp_masuk as timestamp_masuk,
                    a.timestamp_pulang as timestamp_pulang 
                from absensis as a 
                INNER JOIN users as b on a.nip=b.nip
                ".$wherebetween; 
        // $sql = "SELECT 
        //             b.nip as nip,
        //             b.name as username,
        //             DATE_FORMAT(a.timestamp_masuk, '%W, %d - %m - %Y') as timestamp_masuk,
        //             DATE_FORMAT(a.timestamp_pulang,'%W, %d - %m - %Y') as timestamp_pulang,
        //             DATE_FORMAT(a.timestamp_masuk, '%H:%m:%s') AS cl_masuk,
        //             DATE_FORMAT(a.timestamp_pulang, '%H:%m:%s') AS cl_pulang  
        //         from absensis as a 
        //         INNER JOIN users as b on a.nip=b.nip
        //         ".$wherebetween; 
        $result = DB::select($sql);
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>$result));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        } 
    }  
    
    public static function save_history($data){  
        DB::table('history_exports')->truncate();
        $result = DB::table('history_exports')->insert($data); 
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>true));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        } 
    }
    
}
