<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;

use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\Exportable;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

use App\User;
use App\Absensi;
use DB;

class AbsensiExport implements FromView 
{ 
    public function __construct($start, $end)
    {
        $this->start = $start;
        $this->end = $end;
    }
    
    public function view(): View{ 
      return view('exports.absensi', [ 
          'absensi'=>DB::table('absensis as a')
            ->join('users as b', 'a.nip', '=', 'a.nip')
            ->select( 
                "b.nip as nip",  
                "b.name as username",
                "a.timestamp_masuk as timestamp_masuk",
                "a.timestamp_pulang as timestamp_pulang") 
           ->whereBetween('a.timestamp_masuk', [$this->start, $this->end])
            ->get()
            // ->whereDate('a.timestamp_masuk', '>=', $this->start)
            // ->whereDate('a.timestamp_masuk', '<=', $this->end)
      ]);
    } 
}