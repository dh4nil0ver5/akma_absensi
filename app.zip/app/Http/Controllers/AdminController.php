<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Shift;
use App\User;

class AdminController extends Controller{ 
    public function __construct() {
        $this->middleware('auth');
    }
    public function data_shift() {
        return Shift::data_shift();   
    }
    public function data_pegawai() {
        return Shift::data_pegawai();   
    }
    public function pegawai() {  
        return view('admin.pegawai');
    }
    public function lokasi() {
        return view('admin.lokasi');
    }
    public function shift_bydate() {
        return Shift::shift_bydate();   
    }
    public function simpan_pegawai(Request $request) {  
        $data = array(
            "nomer_hp"=>$request->input("nomer_hp"),
            "nip"=>$request->input("nip"),
            "name"=>$request->input("name"),
            "email"=>$request->input("email"),
            "password"=>$request->input("password"),
            "jam_masuk"=>$request->input("jam_masuk"),
            "jam_keluar"=>$request->input("jam_keluar"),
            "admin"=>"bukan admin"
            );
        return User::simpan_pegawai($data);  
    }
    public function simpan_shift(Request $request) {
        $data = array(
            "tanggal"=>$request->input('tanggal'),
            "detail"=>$request->input('detail'), ); 
        return Shift::simpan_shift($data);  
    } 
}
