<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\User; 
use App\Lokasi;
use  Storage;


class DataController extends Controller{
    
    public function check_area(Request $request){
        $access = User::measure_distance($request->input('latitude'), $request->input('longitude'), "miles", 5);
        
        if($access == 1){
            $getUser = DB::table('users')->where('nip',$request->input("nip"))->first();
            
            if($getUser != null){
                //gak usah insert lat long, gak kanggo mas.
                //saya tambahkan field/row date di tabel absensi
                //laporan atau kodingan ini sampean sesuaikan lagi
                
                $insert= null;
                $cekAbsen = DB::table('absensis')
                    ->where('nip',$getUser->nip)
                    ->where('date','=',date('Y-m-d'))
                    ->first();
                    
                if($request->input('masuk') == 1){
                    // if ($cekAbsen == null) {
                        
                        $insert = DB::table('absensis')->insert([
                            "nip"=>$getUser->nip,
                            "date"=>date('Y-m-d'),
                            "timestamp_masuk"=>date("Y-m-d H:i:s"),
                            "status"=>$request->input("status"),
                            "masuk"=>$request->input("masuk")
                        ]);
                        // echo "isi kosong";
                    
                    // } 
                    // else {
                    //     $update = DB::table('absensis')
                    //     ->where('id',$cekAbsen->id)
                    //     ->update([
                    //         "timestamp_masuk"=>date("Y-m-d H:i:s"),
                    //         "status"=>$request->input("status"),
                    //         "masuk"=>$request->input("masuk")
                    //     ]);
                    // }
                    
                } 
                
                // echo $request->input('masuk');
                else if ($request->input('pulang') == 1) {
                    // if ($cekAbsen == null) {
                    //     $insert = DB::table('absensis')->insert([
                    //         "nip"=>$getUser->nip,
                    //         "date"=>date('Y-m-d'),
                    //         "timestamp_pulang"=>date("Y-m-d H:i:s"),
                    //         "status"=>$request->input("status"),
                    //         "pulang"=>$request->input("pulang")
                    //     ]);
                    // } else {
                        $update = DB::table('absensis')
                        ->where('id',$cekAbsen->id)
                        ->update([
                            "timestamp_pulang"=>date("Y-m-d H:i:s"),
                            "status"=>$request->input("status"),
                            "pulang"=>$request->input("pulang")
                        ]);
                    // }
                }
                
                return response()->json([
                    'message' => 'Absen berhasil',
                    'code' => '200',
                ]);
            }
            
            return response()->json([
                'message' => 'User tidak ditemukan',
                'code' => '404',
            ]);
        }
        
        return response()->json([
            'message' => 'Mohon absen pada lokasi yang ditentukan',
            'code' => '500',
        ]);
    }

    
    public function simpan_pegawai(Request $request) {   
        $data = array(
            "nomer_hp"=>$request->input("nomer_hp"),
            "nip"=>$request->input("nip"),
            "name"=>$request->input("name"),
            "email"=>($request->input("email")==null ? "":$request->input("email")),
            "password"=>$request->input("password"),
            "jam_masuk"=>"",
            "jam_keluar"=>"",
            "admin"=>"bukan admin"
            );  
        return User::simpan_pegawai($data);   
    }
    
    public function edit_pegawai($id){
        return User::edit_pegawai($id); 
    }
    
    public function ubah_pegawai(Request $request){
        $data = [
            "nomer_hp"=>$request->input("nomer_hp"),
            "nip"=>$request->input("nip"),
            "name"=>$request->input("name"),
            "email"=>$request->input("email"),
            "password"=>$request->input("password"),
            "jam_masuk"=>$request->input("jam_masuk"),
            "jam_keluar"=>$request->input("jam_keluar"),
            "admin"=>"bukan admin"
            ];
            $id = $request->input("id_pegawai");
            return User::ubah_pegawai($id, $data); 
    }
    
    public function hapus_pegawai($id){ 
        return User::hapus_pegawai($id); 
    }
    
    public function login_checklog(Request $request){ 
        date_default_timezone_set("Asia/Bangkok");
        $data = array( 
            "username"=>$request->input('username'),
            "password"=>$request->input('password'),
            "latitude"=>$request->input('latitude'),
            "longitude"=>$request->input('longitude'),
            "status"=>$request->input('status'),
            "masuk"=>$request->input('masuk'), 
            "pulang"=>$request->input('pulang'),
            "timestamp_masuk"=>date("Y-m-d H:m:s",time()), 
            "keterangan"=>User::check_keterangan(date("H:m:s",time()), $request->input('username'))
            );
        $response= User::absen_masuk($data); 
    	return $response; 
    }
    
    public function update_checklog(Request $request){
        $data = array(
            "nip"=>$request->input('nip'),
            "time"=>$request->input('time'), 
            "keterangan"=>3
            );   
        $response= User::update_checklog($data); 
    	return $response;
    } 
    
    public function check_pulang($nip){
        $data = array("nip"=>$nip);   
        // $data = array("nomer_hp"=>$nomer_hp);   
        $response= User::check_pulang($data); 
    	return $response;
    }    
    
    public function absen_karyawan($nip){ 
        $data = array("nip"=>$nip);    
        $response= User::ambil_data($data); 
    	return $response;
    }
    
    public function data_absen($start_date,$end_date){
        return User::data_absen($start_date,$end_date);  
    } 
    
    public function attendance_login(Request $request){
        $data = array( 
            "nip"=>$request->input('nip'),
            "password"=>$request->input('password') 
        );
        
        $response = User::attendance_login($data); 
    	return $response; 
    }
    
    public function attendance_history(Request $request){
        $data = array( 
            "nip"=>$request->input('nip')
        );
        
        $response = User::attendance_history($data); 
    	return $response; 
    }
    
    public function attendance_insert(Request $request){
        date_default_timezone_set("Asia/Jakarta");
        $access = User::measure_distance($request->input('latitude'), $request->input('longitude'), "miles", 5);
        
        if($access == 1){
            $getUser = DB::table('users')->where('nip',$request->input("nip"))->first();
            
            if($getUser != null){
                $cekAbsen = DB::table('absensis')
                    ->where('nip',$getUser->nip)
                    ->where('date','=',date('Y-m-d'))
                    ->first();
                    
                if($request->input('masuk') == 1){
                    if($cekAbsen != null){
                        $update = DB::table('absensis')
                        ->where('id',$cekAbsen->id)
                        ->update([
                            "timestamp_masuk"=>date("Y-m-d H:i:s"),
                            "status"=>$request->input("status"),
                            "masuk"=>$request->input("masuk")
                        ]);
                    } 
                    else {
                        $insert = DB::table('absensis')->insert([
                            "nip"=>$getUser->nip,
                            "date"=>date('Y-m-d'),
                            "timestamp_masuk"=>date("Y-m-d H:i:s"),
                            "status"=>$request->input("status"),
                            "masuk"=>$request->input("masuk")
                        ]);
                    }
                    
                } 
                
                else if ($request->input('pulang') == 1) {
                    if ($cekAbsen != null) {
                        $update = DB::table('absensis')
                        ->where('id',$cekAbsen->id)
                        ->update([
                            "timestamp_pulang"=>date("Y-m-d H:i:s"),
                            "status"=>$request->input("status"),
                            "pulang"=>$request->input("pulang")
                        ]);
                    } else {
                        $insert = DB::table('absensis')->insert([
                            "nip"=>$getUser->nip,
                            "date"=>date('Y-m-d'),
                            "timestamp_pulang"=>date("Y-m-d H:i:s"),
                            "status"=>$request->input("status"),
                            "pulang"=>$request->input("pulang")
                        ]);
                    }
                }
                
                return response()->json([
                    'message' => 'Absen berhasil'
                ],200);
            }
            
            return response()->json([
                'message' => 'User tidak ditemukan'
            ],404);
        }
        
        return response()->json([
            'message' => 'Mohon absen pada lokasi yang ditentukan'
        ],500);
    }
}
