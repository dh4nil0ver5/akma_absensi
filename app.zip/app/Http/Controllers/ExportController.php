<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request; 
use App\Absensi;

class ExportController extends Controller
{
    //
    public function excel_absensi() 
    {  
        return Absensi::excel_absensi();   
    }
    
    public function save_history(Request $request) {
        $data = ["tanggal_range"=> $request->input('starts')." / ".$request->input('ends')];
        return Absensi::save_history($data);   
    }
}
