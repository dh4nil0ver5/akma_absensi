<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB; 
use App\Lokasi; 


class LokasiController extends Controller{
    
    public function index(){
        return view('admin.lokasi');
    } 
    
    public function data_lokasi(){ 
        $response= Lokasi::data_lokasi();
        return $response;
    }
    
    public function ambil_lokasi($id){ 
        $response= Lokasi::lokasi_byid($id);
        return $response;
    }
    
    public function ubah_lokasi(Request $request){ 
        $id = $request->input('id');
        $data = [
            "nama_lokasi"=>$request->input('nama_lokasi'),
            "latitude"=>$request->input('latitude'),
            "longitude"=>$request->input('longitude') ];
        $response= Lokasi::ubah_lokasi($id, $data);
        return $response;
    }
    
    public function insert_lokasi(Request $request){ 
        $data = [ 
            "nama_lokasi"=>$request->input("nama_lokasi"),
            "latitude"=>$request->input("latitude"),
            "longitude"=>$request->input("longitude"),
            ];
        $response= Lokasi::insert_lokasi($data);
        return $response;
    }
    
    public function hapus_lokasi($id){   
        $response= Lokasi::hapus_lokasi($id);
        return $response;
    }
    
}