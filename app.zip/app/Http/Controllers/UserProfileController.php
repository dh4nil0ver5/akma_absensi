<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Storage;
use DB;

class UserProfileController extends Controller
{
    public function index()
    {
        return redirect("/home");
    }

    public function update(Request $request)
    {
        if ($request->user()->avatar) {
            Storage::delete($request->user()->avatar);
        }

        $avatar = $request->file('avatar')->store('avatars');

        // $request->user()->update([
        //     'avatar' => $avatar
        // ]);

        $data = array(
            "nomer_hp"=>$request->input('nomer_hp'),
            "nip"=>$request->input('nip'),
            "name"=>$request->input('name'),
            "email"=>$request->input('email'),
            "password"=>$request->input('password'),
            "avatar"=>$avatar,
        );
        $result = DB::table('users')->insert($data);
        echo '1'; 
    }

    public function destroy(Request $request)
    {
        if ($request->user()->avatar) {
            Storage::delete($request->user()->avatar);
        }

        $request->user()->update([
            'avatar' => null
        ]);

        return "oke";
        // return redirect()->back();
    }
}
