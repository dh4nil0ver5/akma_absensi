<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
        //
        'profil',
        'login',
        'logout',
        'simpan_shift',
        'login_mobile',
        'update_checklog',
        'attendance_login',
        'attendance_history',
        'attendance_insert',
        'save_karyawan',
        'simpan_pegawai',
        'ubah_pegawai',
        'simpan_lokasi', 
        'save_history',
    ];
}
