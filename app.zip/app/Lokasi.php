<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use DB;

class Lokasi extends Model
{
    //
    protected $fillable = ['nama_lokasi', 'latitude', 'longitude', 'create_at'];
    
    public static function data_lokasi(){ 
        $result = DB::table('lokasis')->get();
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>$result));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }
    
    public static function lokasi_byid($id){ 
        $result = DB::table('lokasis')->where("id",$id)->get();
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>$result));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }
    
    public static function hapus_lokasi($id){ 
        $result = DB::table('lokasis')->where("id",$id)->delete();
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>$result));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }
    
    public static function insert_lokasi($data){ 
        $result = DB::table('lokasis')->insert($data);
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>true));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }
    
    public static function ubah_lokasi($id, $data){ 
        $result = DB::table('lokasis')->where("id",$id)->update($data);
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>$result));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }
}