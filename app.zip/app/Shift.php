<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use DB;

class Shift extends Model
{
    //
    protected $fillable = [
        'nama_shift', 'start', 'ends',
    ];

    public static function data_pegawai(){
        $result = DB::table('absensis')->get();
        $shift = DB::table('shifts')->get();
        $users = DB::table('users')->where('admin','bukan admin')->get();
        if ($result) { 
            return json_encode(array("absensis"=>$result,"shift"=>$shift,"users"=>$users));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }

    public static function data_shift(){ 
        $result = DB::table('shifts')->get();
        if ($result) { 
            return json_encode($result);
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }

    public static function shiftbydate(){ 
        $result = DB::select('SELECT * FROM shifts WHERE created_at >= CURRENT_DATE()');
        if ($result) { 
            return json_encode($result);
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }


    public static function simpan_shift($data){
        // print_r($data);
        $result = DB::table('shifts')->insert($data);
        if ($result) { 
            return json_encode($result);
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    } 
}
