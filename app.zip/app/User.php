<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

use Illuminate\Support\Facades\DB;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'avatar',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function getAvatar()
    {
        if (!$this->avatar) {
            return null;
        }

        return asset('images/'. $this->avatar);
    }
    
    public static function check_keterangan($date_in, $users){ 
        $res=''; 
        $sql = "SELECT if(jam_masuk>'$date_in', 1, 2) as hasil FROM `users` where nip='".$users."' "; 
        $db = DB::select($sql);        
        if($db[0]->hasil == 1){
            return 1;
        }else{
            return 2;
        }
    } 
    
    public static function absen_masuk($data){    
        $n = $data['nomer_hp']; $p = $data['nip'];  
        $akun = DB::table('users')
        ->select('*')
        //->where('nomer_hp','=',$n)
        ->where('nip','=',$p)
        ->get();  
        
        if ($akun->count() == 1) { 
            $akun = DB::select('select radius, latitude, longitute from lokasi');
            print_r($akun);
            // $radius = $akun[0]->radius;
            // $lokasi_lat = $akun[0]->latitude;
            // $lokasi_log = $akun[0]->longitute; 
            
            $div_lat = $data['latitude'];
            $div_log = $data['logitude']; 

            $res = $this->getDistanceBetweenPointsNew($lokasi_lat, $lokasi_log, $div_lat, $div_log, "miles");

            //note 25 m

            $result = DB::table('absensis')->insert($data); 
            return json_encode(array("status"=>200, "data"=>$akun, "count"=>$akun->count()));
        }else {
            return json_encode(array("status"=>400, "data"=>false, "count"=>0)); 
        }
    }
    
    public static function simpan_pegawai($data){  
        $result = DB::table('users')->insert($data); 
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>true));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        } 
    }
    
    public static function edit_pegawai($id){  
            $result = DB::table('users')->where("id","=",$id)->get(); 
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>$result));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }
    
    public static function ubah_pegawai($id, $data){  
        $result = DB::table('users')->where("id",$id)->update($data); 
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>true));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }
    
    public static function hapus_pegawai($id){ 
        $result = DB::table('users')->where("id","=",$id)->delete(); 
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>true));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }
    
    public static function data_absen($start_date,$end_date){  
        
        $a = ($start_date == 0 ? "":$start_date);
        $b = ($end_date == 0 ? "":$end_date);
        $final_sql = "";
        $wherebetween = " WHERE b.admin='bukan admin' AND a.timestamp_masuk BETWEEN '".$a."' AND '".$b."'";
        if($a==""){
        // $sql = "SELECT 
        //             a.nip as nip,
        //             a.name as username,
        //             a.jam_masuk as jam_masuk,
        //             a.jam_keluar as jam_keluar,
        //         DATE_FORMAT(b.timestamp_masuk, '%W, %d - %m - %Y') as timestamp_masuk,
        //         DATE_FORMAT(b.timestamp_pulang,'%W, %d - %m - %Y') as timestamp_pulang,
        //         DATE_FORMAT(b.timestamp_masuk, '%H:%m:%s') AS cl_masuk,
        //         DATE_FORMAT(b.timestamp_pulang, '%H:%m:%s') AS cl_pulang
        //         from users a 
        //         inner join absensis b on b.nip=a.nip
        //         where a.admin='bukan admin' "; 
        $sql = "SELECT 
                    a.nip as nip,
                    a.name as username, 
                    b.timestamp_masuk as timestamp_masuk,
                    b.timestamp_pulang as timestamp_pulang 
                from users a 
                inner join absensis b on b.nip=a.nip
                where a.admin='bukan admin' "; 
        $final_sql=$sql;
        }else{
        // $sql = "SELECT 
        //             b.nip as nip,
        //             b.name as username,
        //             DATE_FORMAT(a.timestamp_masuk, '%W, %d - %m - %Y') as timestamp_masuk,
        //             DATE_FORMAT(a.timestamp_pulang,'%W, %d - %m - %Y') as timestamp_pulang,
        //             DATE_FORMAT(a.timestamp_masuk, '%H:%m:%s') AS cl_masuk,
        //             DATE_FORMAT(a.timestamp_pulang, '%H:%m:%s') AS cl_pulang  
        //         from absensis as a 
        //         INNER JOIN users as b on a.nip=b.nip
        //         ".$wherebetween; 
        $sql = "SELECT 
                    b.nip as nip,
                    b.name as username,
                    a.timestamp_masuk as timestamp_masuk,
                    a.timestamp_pulang as timestamp_pulang 
                from absensis as a 
                INNER JOIN users as b on a.nip=b.nip
                ".$wherebetween; 
        $final_sql=$sql; 
        // echo $final_sql;
        } 
        $result = DB::select($final_sql); 
        if ($result) {  
            return json_encode(array("status"=>200, "data"=>$result));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    } 
    public static function login($data){ 
        $result = DB::table('users')
            ->where($data)->get();
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>$result, 'count'=>$result->count()));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }
    public static function pulang($data){
        $result = DB::table('absensis')
            ->where($data);
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>true));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        }
    }    
    public static function check_pulang($data){
        $sql= "SELECT * FROM absensis WHERE status=1 AND masuk=1 AND pulang=0 AND nip='".$data['nip']."' AND timestamp_masuk >= NOW() - INTERVAL 1 DAY"; 
        $sql = "SELECT if(jam_keluar>'$date_in', 1, 2) as hasil FROM `users` where nip='".$data['nip']."' "; 
        $result = DB::select($sql); 
        return json_encode($result);
        // if (!$result) { 
        //     return json_encode(array("status"=>400, "count"=>count($result), "data"=>$result, "_token"=>csrf_token()));
        // }else {
        //     return json_encode(array("status"=>200, "count"=>count($result), "data"=>$result));
        // }
    }
    public static function update_checklog($data){
        $sql = "update absensis set pulang=1, masuk=1, status=1, timestamp_pulang=now(), ". 
            "keterangan=".$data['keterangan']." ".
            "WHERE nip=".$data['nip'];
        $result = DB::update($sql); 
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>true));
        }else {
            return json_encode(array("status"=>400, "data"=>false));
        }
    }
 
    public static function range_absensi($start_date,$end_date){  
        $result = DB::table('absensis')
           ->whereBetween('timestamp_masuk', [$start_date, $end_date])
           ->get();
        if ($result) { 
            return json_encode(array("status"=>200, "data"=>$result));
        }else {
            return json_encode(array("status"=>400, "data"=>false)); 
        } 
    }
    
    public static function ambil_data($data){
        $sql = "SELECT  
                a.id as id,
                DATE_FORMAT(a.timestamp_masuk, '%W, %d %M %Y') as timestamp_masuk,
                DATE_FORMAT(a.timestamp_pulang, '%W, %d %M %Y') as timestamp_pulang,
                TIME(a.timestamp_masuk, '%H:%m') AS cl_masuk,
                TIME(a.timestamp_pulang, '%H:%m') AS cl_pulang, 
                a.keterangan as keterangan
            FROM absensis a
            WHERE masuk=1 AND pulang=1 AND nip='".$data['nip']."' AND timestamp_masuk >= NOW() - INTERVAL 5 DAY";  
            echo $sql;
        $result = DB::select($sql);   
        $detail = DB::table('users')->where('nip',$data["nip"])->get(); 
        if ($result) {  
            return json_encode(array("absen"=>$result, "detail"=>$detail));
        }else {
            return json_encode(array("status"=>400, "count"=>count($result), "data"=>$result));
        }; 
    }
    
    //$latitude1,  $longitude1 dikantor
    //$latitude2, $longitude2 diuser
    //
    public static function getDistanceBetweenPointsNew($latitude1, $longitude1, $latitude2, $longitude2, $unit = 'meters') {
        $theta = $longitude1 - $longitude2; 
        $distance = (sin(deg2rad($latitude1)) * sin(deg2rad($latitude2))) + (cos(deg2rad($latitude1)) * cos(deg2rad($latitude2)) * cos(deg2rad($theta))); 
        $distance = acos($distance); 
        $distance = rad2deg($distance); 
        $distance = $distance * 60 * 1.1515; 
        switch($unit) { 
          case 'miles': 
            break; 
          case 'kilometers' : 
            $distance = $distance * 1.609344; 
            break; 
          case 'meters' : 
            $distance = $distance * 1609.34; 
        } 
        return (round($distance,2)); 
   }
   
   public static function attendance_login($data){  
        $result = DB::table('users')->where('nip',$data['nip'])->where('password',$data['password'])->first();  
        if($result != null){  
            return response()->json(['message'=>'Berhasil login','data'=>$result],200);
        }
        
        return response()->json(['message'=>'Gagal login'],404);
    }
    
    public static function attendance_history($data){  
        // $result = DB::table('absensis')->select(DB::raw('TIME(timestamp_masuk) as jam_masuk'),DB::raw('TIME(timestamp_pulang) as jam_pulang'),DB::raw('DATE_FORMAT(date, "%d-%m-%Y") as date'))->where('nip',$data['nip'])->limit(7)->orderByDesc('date')->get();  
        $result = DB::table('absensis')->select(DB::raw('TIME(timestamp_masuk) as jam_masuk'),DB::raw('TIME(timestamp_pulang) as jam_pulang'),DB::raw('date as date'))->where('nip',$data['nip'])->limit(7)->orderByDesc('date')->get();  
        
        $items = array();
        foreach($result as $key=>$value){
            $array = [];
            $array["jam_masuk"] = $value->jam_masuk;
            $array["jam_pulang"] = $value->jam_pulang;
            $t = explode("-", $value->date);
            $array["date"] = $t[2]."-".$t[1]."-".$t[0];
            $items[$key] = $array;
        }
         
        if($result != null){  
            // return response()->json(['message'=>'Berhasil','data'=>$result],200);
            return response()->json(['message'=>'Berhasil','data'=>$items],200);
        }
        
        return response()->json(['message'=>'Gagal'],404);
    }
   
   public static function measure_distance($latitude, $longitude, $unit = 'meters', $diameter = 5) {
        $locations = DB::table('lokasis')->get();
        
        $access = 0;
        foreach($locations as $location) {
            if($access == 0){
                $theta = $location->longitude - $longitude; 
                $distance = (sin(deg2rad($location->latitude)) * sin(deg2rad($latitude))) + (cos(deg2rad($location->latitude)) * cos(deg2rad($latitude)) * cos(deg2rad($theta))); 
                $distance = acos($distance); 
                $distance = rad2deg($distance); 
                $distance = $distance * 60 * 1.1515; 
                switch($unit) { 
                  case 'miles': 
                    break; 
                  case 'kilometers' : 
                    $distance = $distance * 1.609344; 
                    break; 
                  case 'meters' : 
                    $distance = $distance * 1609.34; 
                } 
                
                if($access == 0 && $distance <= $diameter){
                    $access = 1;
                }
            }
        }
        
        return $access; 
   }
} 