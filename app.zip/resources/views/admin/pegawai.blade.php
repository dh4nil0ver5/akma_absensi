@extends('layouts.app_admin')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 dash-page">  
            <div class="card">
                <div class="card-header">
                    <ul class="nav nav-tabs">
                        <li class="nav-active active" id="tab_pegawai"><a data-toggle="tab" href="#content-pegawai">Data Pegawai</a></li>
                        <li class="nav-active" id="tab_absensi"><a data-toggle="tab" href="#content-absensi">Absensi Pegawai</a></li> 
                    </ul>  
                </div>
                <div class="card-body"> 
                    <div class="tab-content">
                        <div id="content-pegawai" class="tab-pane fade in active show">  
                            <div id="page_pegawai" class="table-responsive row" style="width: 95%;">
                                <div class="row" style="margin-bottom: 10px;">
                                    <div class="col-md-12">
                                        <div class="btn btn-primary btn-xs btn-flat" id="tambah_Pegawai">
                                            <i class="fas fa-save"></i>&nbsp;&nbsp;Tambah
                                        </div>
                                    </div>
                                </div>
                                <table id="data_pegawai" style="width: 100%; text-align: center;">
                                    <thead>
                                        <tr>
                                            <td>No</td>
                                            <td>NIP</td>
                                            <td>Nama</td>
                                            <!--<td>Shift</td>  -->
                                            <td>aksi</td>  
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                        <div id="content-absensi" class="tab-pane fade"> 
                            <div class="row">
                                <div class="col-md-8 form-inline" style=""> 
                                    <div class="btn btn-primary btn-xs btn-flat none" id="backTableShift">
                                        <i class="fas fa-arrow-left"></i>&nbsp;&nbsp;
                                    </div> 
                                    <h3 id="absensi_title">Data Absensi</h3>
                                    <h3 id="shift_title" class="none">Data Shift</h3>
                                    <h3 id="shift_title_frm" class="none">Tambah Data Shift</h3>
                                </div>
                                <div class="col-md-4" style="text-align: right;">
                                    <div class="btn-group">
                                        <button class="btn btn-primary btn-xs btn-flat" id="btnExport">
                                            <i class="fas fa-file"></i>&nbsp;&nbsp;Export
                                        </button>
                                        <!--<div class="btn btn-primary btn-xs btn-flat none" id="tambahShift">-->
                                        <!--   <i class="fas fa-plus"></i>&nbsp;&nbsp;Tambah Shift-->
                                        <!--</div>-->
                                        <!--<div class="btn btn-success btn-xs btn-flat" id="btnShift">-->
                                        <!--   <i class="fas fa-clock"></i>&nbsp;&nbsp;Shift-->
                                        <!--</div>-->
                                        <div class="btn btn-warning btn-xs btn-flat" id="btnReload">
                                            <i class="fas fa-sync"></i>&nbsp;&nbsp;Segarkan
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <div id="page_absensi" class="table-responsive" style="widtd: 95%;">
                                <div class="text-center"><input type="text" name="dates" value="01/01/2021 - 01/31/2021" /></div>
                                <table id="data_absensi" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <td><center>No</center></td>
                                            <td><center>NIP</center></td>
                                            <td><center>Username</center></td> 
                                            <!--<td>Shift</td> -->
                                            <td><center>Masuk</center></td>
                                            <td><center>Pulang</center></td>
                                            <!--<td><center>Keterangan</center></td> -->
                                        </tr>
                                    </thead>
                                </table>
                            </div> 
                            <div id="page_shift" class="table-responsive row none" style="width: 95%;">
                                <div class="container" hidden> 
                                    <div id="calendar"></div>
                                </div>
                            </div>
                            <!-- <div id="shift" class="row none" style="width: 95%;"> 
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Nama</label>
                                        <div class="col-sm-10">
                                            <input type="text"  style="widtd: 100%;" class="form-control-plaintext" 
                                            id="nama_shift" placeholder="masukkan disini">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12"> 
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">rentang jam</label>
                                        <div class="col-sm-10 row"> 
                                            <input class="form-control col-sm-3 simpleExample" type="text" id="starts"/>
                                            <input class="form-control col-sm-3 simpleExample" type="text" id="ends"/>
                                        </div>
                                    </div>
                                </div>   
                                <div class="col-md-12">
                                    <div class="btn-group">
                                        <div class="btn btn-primary btn-xs" id="saveShift">
                                            <i class="fas fa-save"></i>&nbsp;&nbsp;&nbsp;Simpan & Ok !
                                        </div>
                                        <div class="btn btn-warning btn-xs" id="backShift">
                                            <i class="fas fa-save"></i>&nbsp;&nbsp;&nbsp;Kembali!
                                        </div>
                                    </div>
                                </div>   
                            </div> -->
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="frmNewPegawai" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Pegawai Baru</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
         <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="{{ route('simpan_pegawai') }}" method="post" enctype="multipart/form-data" id="upload_form">
            <div class="modal-body"> 
                <div class="row">
                    <div class="col-md-4">
                        <div class="row form-group{{ $errors->has('avatar') ? ' has-error' : '' }}"  style="width: 100%; display: flex; flex-direction: column;">
                            <label for="avatar" class="col-md-12 control-label"  style="text-align: center">Photo</label>
                            <img src="" alt="">
                            <div class="col-md-12" style="width: 100%; display: flex; flex-direction: column;">
                                <img src="{{ auth()->user()->getAvatar() }}" alt="" height="128">

                                @if (auth()->user()->avatar !== null)
                                    <a href="{{ route('avatar.delete') }}"
                                        style="margin-top: 5%;"
                                        class="btn btn-danger col-md-12"
                                        onclick="event.preventDefault();
                                            document.getElementById('remove-avatar').submit();
                                        ">
                                    Hapus Avatar</a>
                                @endif

                                <input id="avatar" type="file" class="form-control" name="avatar" required>

                                @if ($errors->has('avatar'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('avatar') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div> 
                    <div class="col-md-12">
                        <div class="row form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Nomer hp</label>

                            <div class="col-md-8">
                                <input type="text" class="form-control none" name="update" value="0"/>
                                <input id="nomer_hp" type="number" class="form-control" name="nomer_hp" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div> 
                        <div class="row form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Nip</label>

                            <div class="col-md-8">
                                <input id="nip" type="text" class="form-control" name="nip" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>
                        <div class="row form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Nama</label>
                            <div class="col-md-8">
                                <input id="nama" type="text" class="form-control" name="name" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>
                        <div class="row form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Email</label>
                            <div class="col-md-8">
                                <input id="email" type="email" class="form-control" name="email" placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>
                        <div class="row form-group">
                            <label for="name" class="col-md-4 control-label">Password</label>
                            <div class="col-md-8">
                                <input id="password" type="password" class="form-control" name="password" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>
                        <div class="row form-group none" >
                            <label for="name" class="col-md-4 control-label">admin</label>
                            <div class="col-md-8">
                                <input id="admin" type="name" class="form-control" name="admin" value="bukan admin" style="width: 100%;">
                            </div>
                        </div>                         
                        <!--<div class="row form-group" >-->
                        <!--    <label for="name" class="col-md-4 control-label">jam masuk</label>-->
                        <!--    <div class="col-md-8">-->
                        <!--        <input id="admin" type="time" class="form-control" name="jam_masuk" style="width: 100%;">-->
                        <!--    </div>-->
                        <!--</div>                         -->
                        <!--<div class="row form-group" >-->
                        <!--    <label for="name" class="col-md-4 control-label">jam keluar</label>-->
                        <!--    <div class="col-md-8">-->
                        <!--        <input id="admin" type="time" class="form-control" name="jam_keluar" style="width: 100%;">-->
                        <!--    </div>-->
                        <!--</div> -->
                    </div> 
                </div> 
            </div>
        </form>
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" id="savePegawai" value="Save changes" />
            </div>
        <form action="{{ route('avatar.delete') }}" id="remove-avatar" method="POST" hidden>
            {{ csrf_field() }}
            {{ method_field('DELETE') }}
        </form>
    </div>
  </div>
</div>

<div class="modal fade" id="frmUpdatePegawai" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Udah data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
         <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="{{ route('simpan_pegawai') }}" method="post" enctype="multipart/form-data" id="upload_ubahan">
            <div class="modal-body"> 
                <div class="row">
                    <div class="col-md-4">
                        <div class="row form-group{{ $errors->has('avatar') ? ' has-error' : '' }}"  style="width: 100%; display: flex; flex-direction: column;">
                            <label for="avatar" class="col-md-12 control-label"  style="text-align: center">Photo</label>
                            <img src="" alt="">
                            <div class="col-md-12" style="width: 100%; display: flex; flex-direction: column;">
                                <img src="{{ auth()->user()->getAvatar() }}" alt="" height="128">

                                @if (auth()->user()->avatar !== null)
                                    <a href="{{ route('avatar.delete') }}"
                                        style="margin-top: 5%;"
                                        class="btn btn-danger col-md-12"
                                        onclick="event.preventDefault();
                                            document.getElementById('remove-avatar').submit();
                                        ">
                                    Hapus Avatar</a>
                                @endif

                                <input id="avatar" type="file" class="form-control" name="avatar" required>

                                @if ($errors->has('avatar'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('avatar') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div> 
                    <div class="col-md-12">
                        <div class="row form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Nomer hp</label>

                            <div class="col-md-8">
                                <input id="id_pegawai" type="text" class="form-control none" name="id_pegawai" />
                                <input type="text" class="form-control none" name="update" value="1"/>
                                <input id="nomer_hp_up" type="number" class="form-control" name="nomer_hp" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div> 
                        <div class="row form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Nip</label>

                            <div class="col-md-8">
                                <input id="nip_up" type="text" class="form-control" name="nip" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>
                        <div class="row form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Nama</label>
                            <div class="col-md-8">
                                <input id="nama_up" type="text" class="form-control" name="name" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>
                        <div class="row form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Email</label>
                            <div class="col-md-8">
                                <input id="email_up" type="email" class="form-control" name="email" placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>
                        <div class="row form-group">
                            <label for="name" class="col-md-4 control-label">Password</label>
                            <div class="col-md-8">
                                <input id="password_up" type="password" class="form-control" name="password" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>
                        <div class="row form-group none" >
                            <label for="name" class="col-md-4 control-label">admin</label>
                            <div class="col-md-8">
                                <input id="admin_up" type="name" class="form-control" name="admin" value="bukan admin" style="width: 100%;">
                            </div>
                        </div>                         
                        <!--<div class="row form-group" >-->
                        <!--    <label for="name" class="col-md-4 control-label">jam masuk</label>-->
                        <!--    <div class="col-md-8">-->
                        <!--        <input id="jam_masuk_up" type="time" class="form-control" name="jam_masuk" style="width: 100%;">-->
                        <!--    </div>-->
                        <!--</div>                         -->
                        <!--<div class="row form-group" >-->
                        <!--    <label for="name" class="col-md-4 control-label">jam keluar</label>-->
                        <!--    <div class="col-md-8">-->
                        <!--        <input id="jam_keluar_up" type="time" class="form-control" name="jam_keluar" style="width: 100%;">-->
                        <!--    </div>-->
                        <!--</div> -->
                    </div> 
                </div> 
            </div>
        </form>
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" id="saveUbahanPegawai" value="Save changes" />
            </div>
        <form action="{{ route('avatar.delete') }}" id="remove-avatar" method="POST" hidden>
            {{ csrf_field() }}
            {{ method_field('DELETE') }}
        </form>
    </div>
  </div>
</div>

<div class="modal fade" id="frmTambahShift" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Tambah shift</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body"> 
        <div class="row" style="margin-top: 5%;">
            <div class="col-md-3">Tanggal</div>
            <div class="col-md-9"> 
                <div class="input-group bootstrap-datepicker">
                    <input id="date_start" type="text" class=" form-control input-small">
                    <span class="input-group-addon" style="margin-right: 5%;"><i class="fas fa-time"></i></span>
                    <input id="date_end" type="text" class=" form-control input-small">
                    <span class="input-group-addon"><i class="fas fa-time"></i></span>
                </div>
            </div>
        </div>
        <div class="row" style="margin-top: 5%;">
            <div class="col-md-3">Detail </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-2">shift 1</div> 
                    <div class="col-md-10 well" style="width: 100%;"> 
                        <div class="input-group bootstrap-timepicker">
                            <input id="shift1_masuk" type="text" class="input-small">
                            <span class="input-group-addon" style="margin-right: 5%;"><i class="fas fa-time"></i></span>
                            <input id="shift1_pulang" type="text" class="input-small">
                            <span class="input-group-addon"><i class="fas fa-time"></i></span>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-top: 2%;">
                    <div class="col-md-2">shift 2</div>
                    <div class="col-md-10">
                        <div class="input-group bootstrap-timepicker">
                            <input id="shift2_masuk" type="text" class="input-small">
                            <span class="input-group-addon" style="margin-right: 5%;"><i class="fas fa-time"></i></span>
                            <input id="shift2_pulang" type="text" class="input-small">
                            <span class="input-group-addon"><i class="fas fa-time"></i></span>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-top: 2%;">
                    <div class="col-md-2">shift 3</div>
                    <div class="col-md-10">
                        <div class="input-group bootstrap-timepicker">
                            <input id="shift3_masuk" type="text" class="input-small">
                            <span class="input-group-addon" style="margin-right: 5%;"><i class="fas fa-time"></i></span>
                            <input id="shift3_pulang" type="text" class="input-small">
                            <span class="input-group-addon"><i class="fas fa-time"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <div class="modal-footer">
        <div class="btn" id="btnSaveShift">
            <div class="btn-success btn-flat btn-xs">
                <i class="fa fa-save"></i>&nbsp;Save
            </div>
        </div>
      </div>
    </div>
  </div>
</div>

@endsection