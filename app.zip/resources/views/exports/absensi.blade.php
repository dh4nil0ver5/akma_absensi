<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<table border=1>
    <thead>
    <tr>
        <th style="width: 10px; text-align: center;">No</th>
        <th style="width: 10px; text-align: center;">nip</th> 
        <th style="width: 10px; text-align: center;">username</th> 
        <th style="width: 10px; text-align: center;">Masuk</th> 
        <th style="width: 10px; text-align: center;">Pulang</th> 
    </tr>
    </thead>
    <tbody style=""> 
    @foreach($absensi as $key=>$user)
        <tr>
            <td style="width: 10px; text-align: center;">{{ ($key+1) }}</td>
            <td style="width: 10px; text-align: center;">{{ $user->nip }}</td> 
            <td style="width: 50px; text-align: center;">{{ $user->username }}</td> 
            <td style="width: 50px; text-align: center;">{{ $user->timestamp_masuk }}</td> 
            <td style="width: 50px; text-align: center;">{{ $user->timestamp_pulang }}</td> 
        </tr>
    @endforeach
    </tbody>
</table>
</body>
</html>