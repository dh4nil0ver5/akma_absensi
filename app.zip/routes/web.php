<?php

Auth::routes();

Route::group(['middleware' => ['web','auth']], function(){
    
    Route::get('/', function(){ 
        return redirect('/home');
    });
    
    // Route::get('/home', 'HomeController@index')->name('home');
    Route::get('/home', function(){ 
        if(Auth::user()->admin == 1){
            $users['users'] = \App\User::all();
            return view('admin.home', $users);
            // return view('home');
        }else { 
            $users['users'] = \App\User::all();
            return view('admin.home', $users);
        }
    });
    
    Route::post('/simpan_shift', 'AdminController@simpan_shift')->name('simpan_shift'); 
    Route::post('/simpan_pegawai', 'AdminController@simpan_pegawai')->name('simpan_pegawai');  
    Route::post('/absen', 'HomeController@absen')->name('absen'); 
    Route::post('/pulang', 'HomeController@pulang')->name('pulang');
});
 

Route::get('profil', 'UserProfileController@index' )->name('rollback');  
Route::post('save_karyawan', 'UserProfileController@update')->name('profil');
Route::delete('profil', 'UserProfileController@destroy')->name('avatar.delete');

Route::post('/update_checklog', 'DataController@update_checklog')->name('update_checklog');
Route::post('/login_mobile', 'DataController@check_area')->name('login_mobile');
Route::post('/login_checklog', 'DataController@login_checklog')->name('login_checklog'); 
 
Route::post('/save_history', 'ExportController@save_history')->name('save_history'); 
Route::get('/excel_absensi','ExportController@excel_absensi'); 

Route::get('/check_pulang/{nip}', 'DataController@check_pulang')->name('check_pulang');
Route::get('/pegawai', 'AdminController@pegawai')->name('pegawai');
Route::get('/data_pegawai', 'AdminController@data_pegawai')->name('data_pegawai');
Route::get('/edit_pegawai/{id}', 'DataController@edit_pegawai')->name('edit_pegwai');
Route::post('/ubah_pegawai', 'DataController@ubah_pegawai')->name('ubah_pegawai');
Route::get('/hapus_pegawai/{id}', 'DataController@hapus_pegawai')->name('hapus_pegawai');
Route::get('/data_absen/{start_date}/{end_dat}', 'DataController@data_absen')->name('data_absen');
Route::get('/absen_karyawan/{nip}', 'DataController@absen_karyawan')->name('absen_karyawan');
Route::get('/data_shift', 'AdminController@data_shift')->name('data_shift'); 
Route::get('/shift_bydate', 'AdminController@shift_bydate')->name('shift_bydate'); 

Route::get('/lokasi', 'LokasiController@index')->name('lokasi');
Route::get('/data_lokasi', 'LokasiController@data_lokasi')->name('data_lokasi');
Route::get('/ambil_lokasi/{id}', 'LokasiController@ambil_lokasi')->name('ambil_lokasi');
Route::post('/simpan_lokasi', 'LokasiController@insert_lokasi')->name('insert_lokasi');
Route::post('/ubah_lokasi/{start_date}/{end_date}', 'LokasiController@ubah_lokasi')->name('ubah_lokasi');
Route::get('/hapus_lokasi/{id}', 'LokasiController@hapus_lokasi')->name('hapus_lokasi'); 
 
//eky
Route::post('/attendance_login', 'DataController@attendance_login')->name('attendance_login');
Route::post('/attendance_history', 'DataController@attendance_history')->name('attendance_history');
Route::post('/attendance_insert', 'DataController@attendance_insert')->name('attendance_insert');