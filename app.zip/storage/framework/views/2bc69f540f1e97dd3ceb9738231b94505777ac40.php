 

<?php $__env->startSection('content'); ?> 
<div class="container">
    <div class="row justify-content-center"> 
      <div class="col-md-12 dash-page">  
        <div class="card"> 
          <div class="card-body"> 
            <div id="page_pegawai" class="table-responsive row" style="width: 95%;">
              <div class="row" style="margin-bottom: 10px;">
                  <div class="col-md-12">
                      <div class="btn btn-primary btn-xs btn-flat" id="tambah_lokasi">
                          <i class="fas fa-save"></i>&nbsp;&nbsp;Tambah
                      </div>
                  </div>
              </div>
              <table id="data_lokasi" style="width: 100%; text-align: center;">
                  <thead>
                      <tr>
                          <td>No</td>
                          <td>NAMA LOKASI</td>
                          <td>Latitude</td>
                          <td>Longitude</td>  
                          <td>AKSI</td>  
                      </tr>
                  </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>

<div class="modal fade" id="frmTambahLokasi" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="">Tambah Lokasi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
        </div>
        <div class="modal-body"> 
            <form method="post" id="frmlokasi">
                <div class="col-md-12">
                        <div class="row form-group">
                            <label for="name" class="col-md-4 control-label">Nama lokasi</label> 
                            <div class="col-md-8"> 
                                <input id="nama_lokasi" type="text" class="form-control" name="nama_lokasi" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>   
                        <div class="row form-group">
                            <label for="name" class="col-md-4 control-label">Latitude</label> 
                            <div class="col-md-8">
                                <input type="text" class="form-control none" name="update" value="0"/>
                                <input id="latitude" type="text" class="form-control" name="latitude" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>  
                        <div class="row form-group"> 
                            <label for="name" class="col-md-4 control-label">Longitude</label> 
                            <div class="col-md-8">
                                <input type="text" class="form-control none" name="update" value="0"/>
                                <input id="longitude" type="text" class="form-control" name="longitude" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div> 
                    </div> 
                </form>
        </div>
        <div class="modal-footer">
            <input type="submit" class="btn btn-primary" id="saveLokasi" value="Save changes" />
        </div>
    </div>
  </div>
</div>

<div class="modal fade" id="frmUpdateLokasi" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="">Tambah Lokasi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
        </div>
        <div class="modal-body"> 
            <form method="post" id="UpdateLokasi">
                <div class="col-md-12">
                        <div class="row form-group">
                            <label for="name" class="col-md-4 control-label">Nama lokasi</label> 
                            <div class="col-md-8"> 
                                <input type="text" name="update" class="none" value="1"/>
                                <input id="id_lokasi_up" type="text" name="id" class="none" value="1"/>
                                <input id="nama_lokasi_up" type="text" class="form-control" name="nama_lokasi" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>   
                        <div class="row form-group">
                            <label for="name" class="col-md-4 control-label">Latitude</label> 
                            <div class="col-md-8">
                                <input type="text" class="form-control none" name="update" value="0"/>
                                <input id="latitude_up" type="text" class="form-control" name="latitude" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div>  
                        <div class="row form-group"> 
                            <label for="name" class="col-md-4 control-label">Longitude</label> 
                            <div class="col-md-8">
                                <input type="text" class="form-control none" name="update" value="0"/>
                                <input id="longitude_up" type="text" class="form-control" name="longitude" required autofocus placeholder="masukkan data disini !" style="width: 100%;"/>
                            </div>
                        </div> 
                    </div> 
                </form>
        </div>
        <div class="modal-footer">
            <input type="submit" class="btn btn-primary" id="saveUpdateLokasi" value="Save changes" />
        </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_lokasi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>