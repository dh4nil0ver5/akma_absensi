<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center"> 
      <div class="col-md-12 dash-page">  
        <div class="card"> 
          <div class="card-body"> 
            <div id="page_pegawai" class="table-responsive row" style="width: 95%;">
              <div class="row" style="margin-bottom: 10px;">
                  <div class="col-md-12">
                      <div class="btn btn-primary btn-xs btn-flat" id="tambah_Pegawai">
                          <i class="fas fa-save"></i>&nbsp;&nbsp;Tambah
                      </div>
                  </div>
              </div>
              <table id="data_lokasi" style="width: 100%; text-align: center;">
                  <thead>
                      <tr>
                          <td>No</td>
                          <td>NAMA LOKASI</td>
                          <td>Latitude</td>
                          <td>Longitude</td>  
                      </tr>
                  </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
<div class="modal fade" id="frmNewPegawai" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Pegawai Baru</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
         <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="<?php echo e(route('profil')); ?>" method="post" enctype="multipart/form-data" id="upload_form">
             
        </form> 
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_lokasi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>