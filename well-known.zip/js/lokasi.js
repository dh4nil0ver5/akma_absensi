
$(document).ready(function (e) {
    load_lokasi();
    $("#tambah_lokasi").on("click", function(){
        $('#frmTambahLokasi').modal({backdrop: 'static', keyboard: false}); 
    });
    $("#saveLokasi").on("click", function(){ 
        _data = new FormData($("#frmlokasi")[0]); 
        $.ajax({
            url: 'simpan_lokasi',
            type: 'post',
            data: _data,
            dataType: 'json',
            processData: false,
            contentType: false,
            success: function (json) {
    load_lokasi();
                $('#frmTambahLokasi').modal('toggle'); 
            },
            error: function (xhr) {

            }
        });
    });
    $("#saveUpdateLokasi").on("click", function(){ 
        _data = new FormData($("#UpdateLokasi")[0]); 
        $.ajax({
            url: 'ubah_lokasi',
            type: 'post',
            data: _data,
            dataType: 'json',
            processData: false,
            contentType: false,
            success: function (json) {  
                load_lokasi();
                $('#frmUpdateLokasi').modal('toggle'); 
            },
            error: function (xhr) {

            }
        });
    });
});
function load_lokasi(params) {  
    $("#data_lokasi").DataTable().destroy();
    $("#data_lokasi").DataTable({
        processing: true,
        serverSide: false,
        aLengthMenu: [[5, 50, 75, -1], [5, 50, 75, "All"]],
        iDisplayLength: 5,
        bPaginate: true,
        ajax: {
            url: "data_lokasi",
            type: "get",
            dataType: "json",
            dataSrc: function (json) {
                var return_data = new Array();
                $.each(json['data'], function (i, item) { 
                    return_data.push({
                        'NO': '<center>' + (i + 1) + '</center>',
                        'LOKASI': '<center>'+item.nama_lokasi + '</center>',
                        'LATITUDE': '<center>' + item.latitude + '</center>',
                        'LONGITUDE': '<center>' + item.longitude+'</center>', 
                        'AKSI': 
                            '<center>'+
                                '<div class="btn-group">'+
                                    '<button class="btn btn-xs btn-warning btn-flat" onclick="edit('+item.id+')"> '+
                                        '<i class="fas fa-edit"></i>edit'+
                                    '</button>'+                                    
                                    '<button class="btn btn-xs btn-danger btn-flat" onclick="hapus('+item.id+')"> '+
                                        '<i class="fas fa-eraser"></i>hapus'+
                                    '</button>'+
                                '</div>'+
                            '</center>', 
                    });
                }); 
                return return_data;
            }
        },
        columns: [
            { data: 'NO' },
            { data: 'LOKASI' },
            { data: 'LATITUDE' },
            { data: 'LONGITUDE'}, 
            { data: 'AKSI'}, 
        ]
    });
}
function edit(param){ 
    $.ajax({
        url: 'ambil_lokasi/'+param,
        type: 'get', 
        dataType: 'json',
        processData: false,
        contentType: false,
        success: function (json) { 
            _id = json['data'][0]["id"];
            _nama_lokasi = json['data'][0]["nama_lokasi"];
            _latitude = json['data'][0]["latitude"];
            _longitude = json['data'][0]["longitude"];
            $('#id_lokasi_up').val(_id); 
            $('#nama_lokasi_up').val(_nama_lokasi); 
            $('#latitude_up').val(_latitude); 
            $('#longitude_up').val(_longitude); 
            $('#frmUpdateLokasi').modal({backdrop: 'static', keyboard: false}); 
        },
        error: function (xhr) {

        }
    }); 
}
function hapus(param){
    $.ajax({
        url: 'hapus_lokasi/'+param,
        type: 'get', 
        dataType: 'json',
        processData: false,
        contentType: false,
        success: function (json) { 
            load_lokasi();
        },
        error: function (xhr) { 
        }
    }); 
}