var  _shift =  new Array();
var tgl1 =  new Array();
var tgl2 =  new Array();

var n = new Date(); 
$(document).ready(function (e) {
    load_karyawan(); 
    load_absensi(0,0);
    load_shift();  
    
    $("#tambah_Pegawai").on("click", function(){ 
        $('#frmNewPegawai').modal({backdrop: 'static', keyboard: false}); 
    });
    $("#savePegawai").on("click", function(){ 
        _data = new FormData($("#upload_form")[0]); 
        $.ajax({
            url: 'simpan_pegawai',
            type: 'post',
            data: _data,
            dataType: 'json',
            processData: false,
            contentType: false,
            success: function (json) {
                load_karyawan(0,0); 
                $('#frmNewPegawai').modal('toggle'); 
            },
            error: function (xhr) {

            }
        });
    }); 
    $("#saveUbahanPegawai").on("click", function(){ 
        _data = new FormData($("#upload_ubahan")[0]);
        $.ajax({
            url: 'ubah_pegawai',
            type: 'post',
            data: _data,
            dataType: 'json',
            processData: false,
            contentType: false,
            success: function (json) { 
                load_karyawan(0,0); 
                $('#frmUpdatePegawai').modal('toggle'); 
            },
            error: function (xhr) {

            }
        });
    });
    $("#btnShift").on("click", function(){ 
        $("#absensi_title").addClass("none");
        $("#page_shift").removeClass("none");
        $("#tambahShift").removeClass("none");
        $("#shift_title").removeClass("none");
        $("#page_absensi").addClass("none");
        $("#backTableShift").removeClass("none");
    });
    $("#backShift").on("click", function(){   
        $("#absensi_title").removeClass("none");
        $("#page_shift").removeClass("none");
        $("#shift").addClass("none"); 
        $("#shift_title").addClass("none");
        $("#shift_title_frm").addClass("none");
        $("#backTableShift").addClass("none");
    });
    $("#tambahShift").on("click", function () {
        $('#frmTambahShift').modal({ backdrop: 'static', keyboard: false }); 
    });
    $("#backTableShift").on("click", function(){ 
        $("#page_absensi").removeClass("none");
        $("#absensi_title").removeClass("none");
        $("#page_shift").addClass("none");
        $("#tambahShift").addClass("none"); 
        $("#shift").addClass("none"); 
        $("#shift_title").addClass("none");
        $("#shift_title_frm").addClass("none");
        $("#backTableShift").addClass("none");
    });
    $("#btnReload").on("click", function(){
    load_karyawan(); 
    load_absensi();
    });
    $("#btnSaveShift").on("click", function(){
        var v_fd = { a: $("#shift1_masuk").val() + "|" + $("#shift1_pulang").val(),
                    b: $("#shift2_masuk").val() + "|" + $("#shift2_pulang").val(),
                    c: $("#shift3_masuk").val() + "|" + $("#shift3_pulang").val()};
        console.log(v_fd);
        _data = { 
            tanggal: $("#date_start").val() + "|" + $("#date_end").val(),
            detail: JSON.stringify(v_fd),
        }; 
        $.ajax({
            url: 'simpan_shift',
            type: 'post',
            data: _data,
            dataType: 'json',
            success: function (json) {
                load_karyawan(0,0);
                $('#frmNewPegawai').modal('toggle'); 
            },
            error: function (xhr) {

            }
        });
    });
    
    $( "#date_start" ).datepicker({dateFormat: "yy-mm-dd"});
    $( "#date_end" ).datepicker({dateFormat: "yy-mm-dd"});

    $("#shift1_masuk").timepicker();
    $("#shift1_pulang").timepicker();
    
    $("#shift2_masuk").timepicker();
    $("#shift2_pulang").timepicker();
    
    $("#shift3_masuk").timepicker();
    $("#shift3_pulang").timepicker();

    var sdat;
    var edat;
    
    $('input[name="dates"]').daterangepicker({
      autoUpdateInput: false, 
      opens: 'left'
    }, function(start, end, label) {  
        $('input[name="dates"]').val(start.format('YYYY-MM-DD')+" - "+end.format('YYYY-MM-DD'));
        sdat = start.format('YYYY-MM-DD');
        edat = end.format('YYYY-MM-DD');
        // console.log(start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD')); 
        load_absensi(start.format('YYYY-MM-DD'),end.format('YYYY-MM-DD'));
        $.ajax({
            url: 'save_history',
            data: {starts: start.format('YYYY-MM-DD'), ends : end.format('YYYY-MM-DD')},
            type: 'post', 
            dataType: 'json',
            success: function (json) {
                if(json["status"] == 200){  
                    console.log(json);
                }else{
                    Swal.fire('data tidak ada !')
                }
            },
            error: function (xhr) {
    
            }
        });        
    }); 
    
    $("#btnExport").on("click", function () {  
        window.location.href = 'coba.html'; 
    });
});  
function edit(param){
    $.ajax({
        url: 'edit_pegawai/'+param,
        type: 'get', 
        dataType: 'json',
        success: function (json) {
            if(json["status"] == 200){
                _nip = json['data'][0]['nip'];
                _nomer_hp = json['data'][0]['nomer_hp'];
                _name = json['data'][0]['name'];
                _email = json['data'][0]['email'];
                _password = json['data'][0]['password'];
                _jam_masuk = json['data'][0]['jam_masuk'];
                _jam_keluar = json['data'][0]['jam_keluar'];
                $("#id_pegawai").val(param);
                $("#nomer_hp_up").val(_nomer_hp);
                $("#nip_up").val(_nip);
                $("#nama_up").val(_name);
                $("#email_up").val(_email);
                $("#password_up").val(_password);
                $("#admin_up").val(_jam_masuk);
                $("#jam_masuk_up").val(_jam_keluar);
                $("#jam_keluar_up").val(_jam_keluar);
                $('#frmUpdatePegawai').modal({backdrop: 'static', keyboard: false}); 
            }else{
                Swal.fire('data tidak ada !')
            }
        },
        error: function (xhr) {

        }
    });
}
function hapus(param){
    $.ajax({
        url: 'hapus_pegawai/'+param,
        type: 'get', 
        dataType: 'json',
        success: function (json) {
            load_karyawan(); 
        },
        error: function (xhr) {

        }
    });
}
function load_karyawan(params) { 
    $("#data_pegawai").DataTable().destroy();
    $("#data_pegawai").DataTable({
        processing: true,
        serverSide: false,
        aLengthMenu: [[5, 50, 75, -1], [5, 50, 75, "All"]],
        iDisplayLength: 5,
        bPaginate: true,
        ajax: {
            url: "data_pegawai",
            type: "get",
            dataSrc: function (json) {
                var return_data = new Array();
                $.each(json['users'], function (i, item) { 
                    return_data.push({
                        'NO': '<center>' + (i + 1) + '</center>',
                        'NIP': '<center>'+item.nip + '</center>',
                        'USERNAME': '<center>' + item.name + '</center>',
                        'USERNAME': '<center>' + item.name + '</center>',
                        // 'SHIFT': '<center>' + (item.jam_masuk == null ? "-":item.jam_masuk) + ' | '+(item.jam_keluar == null ? "-":item.jam_keluar)+'</center>', 
                        'ACTION': 
                            '<center>' + 
                                '<div class="btn-group">'+
                                    '<button class="btn btn-xs btn-flat btn-warning" onclick="edit('+item.id+')">'+
                                        '<i class="fas fa-edit">&nbsp;&nbsp;Ubah</i>'+
                                    '</button>'+
                                    '<button class="btn btn-xs btn-flat btn-danger" onclick="hapus('+item.id+')">'+
                                        '<i class="fas fa-eraser">&nbsp;&nbsp;hapus</i>'+
                                    '</button>'+
                                '</div>'+
                            '</center>',
                    });
                }); 
                return return_data;
            },
        },
        columns: [
            { data: 'NO' },
            { data: 'NIP' },
            { data: 'USERNAME' },
            // { data: 'SHIFT'}, 
            { data: 'ACTION'}, 
        ]
    });
}
function load_absensi(start,end) {
    $("#data_absensi").DataTable().destroy();
    $("#data_absensi").DataTable({
        processing: true,
        serverSide: false,
        aLengthMenu: [[5, 50, 75, -1], [5, 50, 75, "All"]],
        iDisplayLength: 5,
        bPaginate: true,
        ajax: {
            url: "data_absen/"+start+"/"+end,
            type: "get",
            dataType: "json",
            dataSrc: function (json) { 
                var return_data = new Array();
                nomer = 0;
                // 
                tgl1 = new Array();
                $.each(json['tgl1'], function (i, item) {  
                    tgl1.push(item.dte);
                });

                tgl2 = new Array();
                $.each(json['tgl2'], function (i, item) {
                    tgl2.push(item.dte); 
                }); 
                load_hasil(tgl1);
                console.log(json['data']);
                $.each(json['data'], function (i, item) {
                    _keterangan = "-";
                    return_data.push({
                        'NO': '<center>' + (i + 1) + '</center>',
                        'NIP': '' + item.nip + '',
                        'USERNAME': '' + item.username + '',
                        // 'SHIFT': '<center> '+item.jam_masuk+' | '+item.jam_pulang+' </center>',
                        'MASUK': '<center>' + (item.timestamp_masuk == null ? "-" : item.timestamp_masuk) + '</center>',
                        'KELUAR': '<center>' + (item.timestamp_pulang == null ? "-" : item.timestamp_pulang) + '</center>',
                        // 'STATUS': '<div style="padding: 10px; width: 100%;"><center>' + _keterangan + '</center></div>', 
                        // 'AKSI': '<center>' + 
                        //             '<div class="btn-group">'+
                        //                 '<button class="btn btn-flat btn-xs btn">'+
                        //                     '<i class="fas fa-edit"></i>&nbsp;&nbsp;&nbsp;Edit'+
                        //                 '</button>'+ 
                        //                 '<button class="btn btn-flat btn-xs btn">'+
                        //                     '<i class="fas fa-eraser"></i>&nbsp;&nbsp;&nbsp;Hapus'+
                        //                 '</button>'+
                        //             '</div>'+
                        //         '</center>';
                        });
                    });  
                return return_data;
            },
        },
        columns: [
            { data: 'NO' },
            { data: 'NIP'},
            { data: 'USERNAME'},
            // { data: 'SHIFT'},
            { data: 'MASUK'},
            { data: 'KELUAR'},
            // { data: 'STATUS'},
            // { data: 'AKSI'},
    ]
    });
}
function load_shift() {
    $("#data_shift").DataTable().destroy();
    $("#data_shift").DataTable({
        processing: true,
        serverSide: false,
        aLengthMenu: [[5, 50, 75, -1], [5, 50, 75, "All"]],
        iDisplayLength: 5,
        bPaginate: true,
        ajax: {
            url: "data_shift",
            type: "get",
            dataSrc: function (json) { 
                var return_data = new Array();
                nomer = 0;
                $.each(json, function (i, item) { 
                    return_data.push({
                        'NO': '<center>' + (i + 1) + '</center>',
                        'NAMA': '' + item.nama_shift + '',
                        'MASUK': '<center>' + item.starts + '</center>',
                        'PULANG': '<center>' + item.ends + '</center>', 
                    });
                });
                return return_data;
            },
        },
        columns: [
            { data: 'NO' },
            { data: 'NAMA' },
            { data: 'MASUK' },
            { data: 'PULANG' }, 
        ]
    });
}
function load_hasil(hasil) {
    calendar = new CalendarYvv("#calendar", moment().format("Y-M-D"), "Monday");
    calendar.funcPer = function (ev) {

    }
    calendar.funcPrev = function (ev) {
        console.log(ev);
    }
    calendar.funcNext = function (ev) {
        console.log(ev);
        calendar.diasResal = hasil;
    }
    // calender.diaSeleccionado = n;
    calendar.diasResal = hasil;
    calendar.createCalendar();
}